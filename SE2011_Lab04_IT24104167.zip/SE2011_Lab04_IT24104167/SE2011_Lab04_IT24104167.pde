int state = 0;

int startTime;
int duration = 30;

int score = 0;

float px = 350, py = 175;
float step = 6;
float pr = 20;

float hx, hy;
float ease = 0.08;

float ox = 200, oy = 100;
float xs = 3, ys = 2;
float r = 15;

float ox2 = 500, oy2 = 200;
float xs2 = -2.5, ys2 = 2.2;
float r2 = 15;

boolean trails = false;

void setup() {
  size(700, 350);
  hx = px;
  hy = py;
}

void draw() {

  // Trail effect
  if (!trails) {
    background(255);
  } else {
    noStroke();
    fill(255, 30);
    rect(0, 0, width, height);
  }

  // Start screen
  if (state == 0) {
    textAlign(CENTER, CENTER);
    textSize(26);
    fill(0);
    text("Catch the Orb!", width/2, height/2 - 20);

    textSize(18);
    text("Press ENTER to Start", width/2, height/2 + 20);
  }

  // Play state
  if (state == 1) {

    int elapsed = (millis() - startTime) / 1000;
    int left = duration - elapsed;

    if (left <= 0) {
      state = 2;
    }

    // Player movement
    if (keyPressed) {
      if (keyCode == RIGHT) px += step;
      if (keyCode == LEFT) px -= step;
      if (keyCode == DOWN) py += step;
      if (keyCode == UP) py -= step;
    }

    // Keep player inside screen
    px = constrain(px, pr, width - pr);
    py = constrain(py, pr, height - pr);

    // Helper easing follow
    hx = hx + (px - hx) * ease;
    hy = hy + (py - hy) * ease;

    // Move main orb
    ox += xs;
    oy += ys;

    if (ox > width - r || ox < r) xs *= -1;
    if (oy > height - r || oy < r) ys *= -1;

    // Move second orb
    ox2 += xs2;
    oy2 += ys2;

    if (ox2 > width - r2 || ox2 < r2) xs2 *= -1;
    if (oy2 > height - r2 || oy2 < r2) ys2 *= -1;

    // Collision with main orb
    float d = dist(px, py, ox, oy);
    if (d < pr + r) {
      score++;
      ox = random(r, width - r);
      oy = random(r, height - r);
      xs *= 1.05;
      ys *= 1.05;
    }

    // Collision with second orb
    float d2 = dist(px, py, ox2, oy2);
    if (d2 < pr + r2) {
      score++;
      ox2 = random(r2, width - r2);
      oy2 = random(r2, height - r2);
    }

    // Draw player
    fill(60, 120, 200);
    ellipse(px, py, pr*2, pr*2);

    // Draw helper
    fill(80, 200, 120);
    ellipse(hx, hy, 14, 14);

    // Draw orbs
    fill(255, 120, 80);
    ellipse(ox, oy, r*2, r*2);

    fill(240, 60, 200);
    ellipse(ox2, oy2, r2*2, r2*2);

    // UI
    fill(0);
    textSize(16);
    textAlign(LEFT, TOP);
    text("Score: " + score, 20, 20);
    text("Time: " + left, 20, 40);
    text("Press T for Trails", 20, 60);
  }

  // End screen
  if (state == 2) {
    textAlign(CENTER, CENTER);
    textSize(26);
    fill(0);
    text("Time Over!", width/2, height/2 - 20);

    textSize(20);
    text("Final Score: " + score, width/2, height/2 + 10);

    textSize(16);
    text("Press R to Restart", width/2, height/2 + 40);
  }
}

void keyPressed() {

  // Start game
  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
    score = 0;
  }

  // Restart game
  if (state == 2 && (key == 'r' || key == 'R')) {
    state = 0;
    px = 350;
    py = 175;
    xs = 3;
    ys = 2;
  }

  // Toggle trails
  if (key == 't' || key == 'T') {
    trails = !trails;
  }
}
